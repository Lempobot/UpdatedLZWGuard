package LZW.Compressor;

public class DictionarySizeError extends Exception
{
    public DictionarySizeError(String errorMessage)
    {

        super(errorMessage);
    }
}
